﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Proiect_C____gestiune_bilete_concert
{
    //Implementati o clasa numita CasaDeBilete care sa asigure vanzarea biletelor
    public class CasaDeBilete 
    {

        public class BiletEventArgs : EventArgs
        {
            public string Mesaj { get; }

            public BiletEventArgs(string mesaj)
            {
                Mesaj = mesaj;
            }
        }


        //dictionar bilete 
        public Dictionary<string, int> bilete;

        //dictionar pt clienti in asteptare
        public Dictionary<string, Queue<Client>> clientiInAsteptare;

        //Bilete Suplimentate
        public event EventHandler<BiletEventArgs> BileteSuplimentate;



        //constructor
        public CasaDeBilete() 
        {
            bilete = new Dictionary<string, int>()
            {
                {"Categoria1", 100 },
                {"Categoria2", 100 },
                {"Categoria3", 100 }
            };

            clientiInAsteptare = new Dictionary<string, Queue<Client>>();
        }



        //•	Expune o functie care permite suplimentarea biletelor la o anumita categorie cu un anumit numar
        public void SuplimenteazaBilete(string categorie, int numar)
        {


            // Notifica Clientii care nu au prins bilet referitor la suplimentarea numarului de bilete
            if (bilete.ContainsKey(categorie))
            {
                bilete[categorie] += numar;
                Console.WriteLine($"Au fost adaugate {numar} bilete pentru {categorie}.");
                if (BileteSuplimentate != null)
                {
                    BileteSuplimentate(this, new BiletEventArgs($"Bilete suplimentate pentru {categorie}."));
                }

                if (clientiInAsteptare.ContainsKey(categorie))
                {
                    clientiInAsteptare[categorie].Clear();
                }
                else
                {
                    Console.WriteLine("Categoria specificata nu exista.");
                }

            }
           
        }


        //•	Expune o functie care primeste ca parametru un Client, o Categorie si un NumarDeBilete si incearca finalizarea tranzactiei
        public string VanzareBilete(Client client, string categorie, int nrBilete)
        {
            if(bilete.ContainsKey(categorie) && bilete[categorie]>= nrBilete)//daca biletul din categoria ceruta exista si daca numarul de bilete disponibile din acea categorie este mai mare decat nr de bilete solicitat
            {
                bilete[categorie] -= nrBilete;//eliminam din stoc biletele cerute
                Console.WriteLine($"Au fost vandute {nrBilete} bilete lui {client.Nume} pentru categoria : {categorie}.");
                return "Tranzactie Finalizata";
            }
            else
            {
                //o	Daca numarul de bilete solicitat nu este disponibil, retine intr-o coada Clientul apelant si returneaza un status corespunzator (de exemplu, TranzactieNereusita). 
                if (bilete.ContainsKey(categorie) && bilete[categorie] < nrBilete)
                {
                    Console.WriteLine($"Nu sunt suficiente bilete pentru {categorie}. Se adauga {client.Nume} la lista de asteptare.");

                    if (!clientiInAsteptare.ContainsKey(categorie))//verificam daca nu exista deja o coada pt spectacolul respectiv
                    {
                        clientiInAsteptare[categorie] = new Queue<Client>();//facem o coada noua
                    }

                    clientiInAsteptare[categorie].Enqueue(client);//adaugam clientul in coada de asteptare


                    //Cand numarul de clienti in asteptare dintr-o categorie ajunge la 5, se suplimenteaza biletele cu inca 10 bucati la acea categorie
                    if (clientiInAsteptare[categorie].Count>=5)
                    {
                        SuplimenteazaBilete(categorie, 10);
                    }


                    //Daca acest status este intors catre Client, acesta va subscribe la evenimentul prin care se suplimenteaza biletele la o categorie anume
                    BileteSuplimentate += client.NotificareSuplimentareBilete;



                    return "Tranzactie Nereusita";
                }
                else
                {
                    return "Categoria specificata nu exista sau nu sunt suficiente bilete.";
                }
            }
           return "Vanzare bilete";
        }


    }
}

