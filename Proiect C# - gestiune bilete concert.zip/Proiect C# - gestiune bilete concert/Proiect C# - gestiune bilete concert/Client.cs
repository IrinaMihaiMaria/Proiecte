﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Proiect_C____gestiune_bilete_concert
{
    //Implementati o clasa Client care sa reprezinte o persoana interesata de concert.
    public class Client
    {
        public string Nume { get; set; }
        public string Email { get; set; }

        public Client(string nume, string email)
        {
            Nume = nume;
            Email = email;
        }


        
        public void NotificareSuplimentareBilete(object sender, CasaDeBilete.BiletEventArgs e)
        {
            Console.WriteLine($"{Nume} a primit o notificare: {e.Mesaj}");

        }
    }
}


