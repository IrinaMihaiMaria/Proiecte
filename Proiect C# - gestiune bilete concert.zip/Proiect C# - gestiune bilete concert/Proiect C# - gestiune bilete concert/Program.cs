﻿using Proiect_C____gestiune_bilete_concert;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Proiect_C____gestiune_bilete_concert
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //casa de bilete
            CasaDeBilete casaDeBilete = new CasaDeBilete();

            //clienti
            Client client1 = new Client("Tudor", "tudor@gmail.com");
            Client client2 = new Client("Irina", "irina@gmail.com");
            Client client3 = new Client("Mihai", "mihai@gmail.com");
            Client client4 = new Client("Maria", "maria@gmail.com");
            Client client5 = new Client("Matei", "matei@gmail.com");

            //vindem bilete
            Console.WriteLine( casaDeBilete.VanzareBilete(client1, "Categoria1", 100));
            Console.WriteLine();

            Console.WriteLine(casaDeBilete.VanzareBilete(client2, "Categoria1", 5));
            Console.WriteLine();    

            Console.WriteLine(casaDeBilete.VanzareBilete(client3, "Categoria2", 5));
            Console.WriteLine();

            Console.WriteLine(casaDeBilete.VanzareBilete(client4, "Categoria2", 5));
            Console.WriteLine();

            Console.WriteLine(casaDeBilete.VanzareBilete(client5, "Categoria1", 5));
            Console.WriteLine();


            //suplimentam biletele din Categoria 1
            casaDeBilete.SuplimenteazaBilete("Categoria1", 10);
            Console.WriteLine();

            Console.WriteLine(casaDeBilete.VanzareBilete(client2, "Categoria1", 5));

            Console.ReadKey();
        }
    }



}


